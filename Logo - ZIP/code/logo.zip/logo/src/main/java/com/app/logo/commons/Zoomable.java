/**
 * 
 */
package com.app.logo.commons;

/**
 * @author Rafael
 * @author Jesús
 * 
 */
public interface Zoomable {
	public void setFactor(double factor);

	public double getFactor();
}
