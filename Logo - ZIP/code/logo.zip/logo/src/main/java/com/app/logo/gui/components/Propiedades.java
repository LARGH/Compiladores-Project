/**
 * 
 */
package com.app.logo.gui.components;

/**
 * @author Rafael
 * @author Jesús
 * 
 */
public class Propiedades {

	public static final int PANEL_DE_DIBUJO_ANCHO = 600;
	public static final int PANEL_DE_DIBUJO_LARGO = 600;

}
