/**
 * 
 */
package com.app.logo.interprete;

import java.util.ArrayList;

/**
 * @author Rafael
 * @author Jesús
 * 
 */
public interface Funcion {

	public abstract void ejecutar(Object A, ArrayList parametros);
    
}