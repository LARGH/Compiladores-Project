/**
 * Clase VentanaPrincipal
 */
package com.app.logo.gui.components;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.app.logo.commons.Zoomable;
import com.app.logo.interprete.Parser;

/**
 * @author Rafael Landa Aguirre
 * @author José Leonardo Juárez Bouchan
 * @author Jesús Paniagua Hernández
 * 
 */
public class VentanaPrincipal extends JFrame {

    private JTextArea areaDeCodigo;
    private JScrollPane scrollCodigo;
    private PanelCanvas panelCanvas;
    private JButton ejecutar;
    private JButton limpiar;
    private JSlider zoom;
    private Parser parser;
    private Zoomable zoomPanel;
    boolean modoDebug;
    
    public VentanaPrincipal(){
        
        super("Proyecto Compiladores Logo");
        
        modoDebug = false;
        
        parser = new Parser();
        parser.insertarInstrucciones();
        
        areaDeCodigo = new JTextArea(20,20);
        areaDeCodigo.setFont(new Font("Courier New", Font.PLAIN, 14));
        areaDeCodigo.setLineWrap(true);
        areaDeCodigo.setWrapStyleWord(true);
        areaDeCodigo.setTabSize(4);
        scrollCodigo = new JScrollPane(areaDeCodigo);
        scrollCodigo.setBounds(10,10,400,550);
        
        panelCanvas = new PanelCanvas();
        panelCanvas.setBounds(scrollCodigo.getX()+scrollCodigo.getWidth()+10,
                10,
                Propiedades.PANEL_DE_DIBUJO_ANCHO,
                Propiedades.PANEL_DE_DIBUJO_LARGO);
        panelCanvas.setBackground(new Color(0,41,91));
        zoomPanel = panelCanvas;
        
        ejecutar = new JButton("Ejecutar");
        ejecutar.setBounds(30, 570, 170, 40);
        ejecutar.addActionListener(new ActionListener(){

            public void actionPerformed(ActionEvent ae) {
                parser.limpiar();
                if(parser.compilar(areaDeCodigo.getText()))
                    panelCanvas.setConfiguracion(parser.ejecutar());
                else{
                    parser = new Parser();
                    parser.insertarInstrucciones();
                    panelCanvas.setConfiguracion(parser.getConfiguracion());
                }
                panelCanvas.repaint();
            }
        });
        
        limpiar = new JButton("Limpiar");
        limpiar.setBounds(220, 570, 170, 40);
        
        limpiar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                areaDeCodigo.setText("");
                panelCanvas.getConfiguracion().limpiar();
                panelCanvas.getConfiguracion().setPosicion(0.0, 0.0);
                panelCanvas.getConfiguracion().setAngulo(0);
                panelCanvas.removeAll();
                panelCanvas.repaint();
            }
        });
        
        zoom = new JSlider(JSlider.VERTICAL, -10, 10, 0);
        zoom.setMajorTickSpacing(2);
        zoom.setPaintTicks(true);
        zoom.setBounds(scrollCodigo.getX()+scrollCodigo.getWidth()+
                Propiedades.PANEL_DE_DIBUJO_ANCHO+15, 10, 20, 
                Propiedades.PANEL_DE_DIBUJO_LARGO);
        zoom.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                zoomPanel.setFactor( (((JSlider)e.getSource()).getValue() > 0) ? 
                        zoomPanel.getFactor() + 0.1 : 
                        zoomPanel.getFactor() - 0.1 );
                panelCanvas.repaint();
            }
        });
        
        add(scrollCodigo);
        add(panelCanvas);
        add(ejecutar);
        add(zoom);
        add(limpiar);
        
        setLayout(null);
        setBounds(50,50,
                10+scrollCodigo.getWidth()+panelCanvas.getWidth()+
                zoom.getWidth()+30,649);
        setVisible(true);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
        
    }

}
