/**
 * Interfaz Zoomable
 */
package com.app.logo.commons;

/**
 * @author Rafael Landa Aguirre
 * @author José Leonardo Juárez Bouchan
 * @author Jesús Paniagua Hernández
 * 
 */
public interface Zoomable {
	public void setFactor(double factor);

	public double getFactor();
}
