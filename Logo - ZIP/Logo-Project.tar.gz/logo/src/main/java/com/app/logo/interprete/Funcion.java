/**
 * Interfaz Funcion
 */
package com.app.logo.interprete;

import java.util.ArrayList;

/**
 * @author Rafael Landa Aguirre
 * @author José Leonardo Juárez Bouchan
 * @author Jesús Paniagua Hernández
 * 
 */
public interface Funcion {

	void ejecutar(Object A, ArrayList parametros);
    
}