/**
 * Clase propiedades
 */
package com.app.logo.gui.components;

/**
 * @author Rafael Landa Aguirre
 * @author José Leonardo Juárez Bouchan
 * @author Jesús Paniagua Hernández
 * 
 */
public class Propiedades {

	public static final int PANEL_DE_DIBUJO_ANCHO = 600;
	public static final int PANEL_DE_DIBUJO_LARGO = 600;

}
