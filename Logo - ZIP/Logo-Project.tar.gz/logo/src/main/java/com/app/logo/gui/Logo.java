/**
 * Clase Logo
 */
package com.app.logo.gui;

/**
 * @author Rafael Landa Aguirre
 * @author José Leonardo Juárez Bouchan
 * @author Jesús Paniagua Hernández
 * 
 */
import javax.swing.UIManager;

import com.app.logo.gui.components.VentanaPrincipal;

public class Logo {
	
	private static String lookAndFeelUI = 
			"com.jtattoo.plaf.hifi.HiFiLookAndFeel";
	
	public void run() {
		try {
			UIManager.setLookAndFeel(Logo.lookAndFeelUI);
			new VentanaPrincipal();
		} catch (Exception e) {
		}
	}

	public static void main(String args[]) {
		(new Logo()).run();
	}
}
