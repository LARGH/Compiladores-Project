/**
 * Clase TablaDeSimbolos
 */
package com.app.logo.interprete;

import java.util.ArrayList;

/**
 * @author Rafael Landa Aguirre
 * @author José Leonardo Juárez Bouchan
 * @author Jesús Paniagua Hernández
 * 
 */
public class TablaDeSimbolos {

    ArrayList simbolos;
    
    public TablaDeSimbolos(){
        simbolos = new ArrayList();
    }
    
    public Object encontrar(String nombre){
        for(int i = 0; i < simbolos.size(); i++)
            if(nombre.equals(((Nodo)simbolos.get(i)).getNombre()))
                return ((Nodo)simbolos.get(i)).getObjeto();
        return null;
    }
    
    public boolean insertar(String nombre, Object objeto){
        Nodo nodo = new Nodo(nombre, objeto);
        for(int i = 0; i < simbolos.size(); i++)
            if(nombre.equals(((Nodo)simbolos.get(i)).getNombre())){
                ((Nodo)simbolos.get(i)).setObjeto(objeto);
                return true;
            }
        simbolos.add(nodo);
        return false;
    }
    
    public void imprimir(){
        for(int i = 0; i < simbolos.size(); i++){
            System.out.println(((Nodo)simbolos.get(i)).getNombre()
            		+ ((Nodo)simbolos.get(i)).getObjeto().toString());
        }
    }

}
